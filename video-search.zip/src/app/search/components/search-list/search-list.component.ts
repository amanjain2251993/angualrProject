import { Component, OnInit, Input, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Video } from '../../../shared/models/search.interface';
import {DomSanitizer} from '@angular/platform-browser';

@Component({
  selector: 'app-search-list',
  templateUrl: './search-list.component.html',
  styleUrls: ['./search-list.component.css']
})
export class SearchListComponent implements OnInit {

  @Input() videos: Video[] = [];
  runningVideo = "";

  
  modalRef: BsModalRef = new BsModalRef();
  constructor(private modalService: BsModalService,public sanitizer: DomSanitizer) {}
  ngOnInit() {
  }
  
  openModal(template: TemplateRef<any>,videoId:any) {
    this.modalRef = this.modalService.show(template);
    this.runningVideo = videoId;
  }
  

}